package net.crademc.benjamin.labymod.player;

public class PlayerInfo {

    private String minigame = "Lobby";

    public String getMinigame() {
        return minigame;
    }

    public void setMinigame(String minigame) {
        this.minigame = minigame;
    }
}
